* Encoding: UTF-8.
*=============================================================================.
* 01_DATA_PREPARATION.SPS
* Thesis: The Impact of Sustainability Disclosure Quality on Firm Value:
*         Evidence from NGX-Listed Companies Under the IFRS S1/S2 Reporting
*         Framework
* Objective 1: Assess the quality of sustainability disclosures among
*              NGX-listed companies using the IFRS S1/S2 reporting framework.
* Purpose:     Import the firm-year panel, define variables, screen for
*              completeness, construct derived variables (winsorized
*              controls, EAS), and save the analysis-ready file used by
*              02-06.
* Input:       NGX_Sustainability_Panel_Dataset (raw export of the
*              'Final Sample' tab, NGX_Stage1_Descriptive_Statistics
*              workbook), 611 firm-year rows, 128 firms, FY2021-FY2025.
* Output:      NGX_Panel_Analysis.sav
* Workbook cross-reference (NGX_Stage1_Objective1_Descriptive_Statistics.xlsx):
*   s.1.5 winsorization cut points reproduce Table 5's Tobin_Q_Wins /
*     Leverage_Wins / ROA_Wins columns ('5. Controls & Correlation' tab).
*   s.1.4 Coding_Status_Flag is the source of the provisional-row count
*     cited in Table 6's caution note ('6. Zero-Disclosure Table' tab).
*=============================================================================.

* --- 1.1 Import -------------------------------------------------------------.
* If importing directly from the Excel workbook, use GET DATA below.
* If the .sav file already exists, comment this block out and skip to 1.2.

GET DATA
  /TYPE=XLSX
  /FILE='NGX_Sustainability_Panel_Dataset_UPDATED.xlsx'
  /SHEET=NAME 'Final Sample'
  /CELLRANGE=FULL
  /READNAMES=ON
  /ASSUMEDSTRWIDTH=32767.
DATASET NAME RawPanel.

* --- 1.2 Variable labels and measurement level -------------------------------.
* Several source headers carry parenthetical units/qualifiers - e.g.
* 'SDQ_Score (0-100)', 'Firm_Size (LN Total Assets)', 'Big4_Auditor (1/0)',
* 'NGX_Compliance_Status (CSI)'. GET DATA with READNAMES=ON auto-generates a
* valid SPSS variable name from each such header, but the exact result
* (underscore collapsing, trailing-character handling) varies by column and
* is not something to reproduce by eye column-by-column.
*
* Instead, rename ALL variables by their fixed left-to-right column position:
* the ALL keyword matches the active dataset's current variable order,
* independent of whatever auto-generated name GET DATA assigned. This is
* deterministic regardless of SPSS version/auto-naming behaviour, as long as
* the 'Final Sample' tab's column order is unchanged.

RENAME VARIABLES (ALL =
  Row_Number Firm_ID Ticker Company_Name Sector Year
  Voluntary_Adoption_Period IFRS_S1S2_Adopter_Dummy
  SDQ_Score CDQ_Score
  Shares_Outstanding Share_Price_YearEnd Market_Value_Equity
  Total_Liabilities Total_Assets Net_Income
  Tobin_Q_raw Firm_Size Leverage_raw ROA_raw
  Year_Incorporation Firm_Age
  Big4_Auditor Auditor_Name Notes_DataQuality NGX_Compliance_Status).

* If the source workbook's column order or count ever changes, update the
* name list above to match (count and order must line up 1-for-1 with the
* 'Final Sample' tab's header row).

VARIABLE LABELS
  Firm_ID                    'Unique firm identifier'
  Ticker                     'NGX ticker symbol'
  Sector                     'NGX sector classification'
  Year                       'Fiscal year'
  IFRS_S1S2_Adopter_Dummy    'Early Adoption Status (EAS): 1 = early adopter of IFRS S1/S2'
  SDQ_Score                  'Sustainability Disclosure Quality index (IFRS S1), 0-100'
  CDQ_Score                  'Climate-related Disclosure Quality index (IFRS S2), 0-100'
  Tobin_Q_raw                'Tobin''s Q (raw): (Market Value of Equity + Total Liabilities) / Total Assets'
  Firm_Size                  'Firm size: natural log of total assets'
  Leverage_raw               'Leverage (raw): Total Liabilities / Total Assets'
  ROA_raw                    'Return on assets (raw)'
  Firm_Age                   'Firm age in years (current year - year of incorporation)'
  NGX_Compliance_Status      'NGX Corporate Scorecard Index compliance status flag'.

VALUE LABELS IFRS_S1S2_Adopter_Dummy 0 'Non-adopter' 1 'Early adopter'.

VARIABLE LEVEL
  Firm_ID Ticker Sector Year Auditor_Name NGX_Compliance_Status (NOMINAL)
  /IFRS_S1S2_Adopter_Dummy Big4_Auditor (NOMINAL)
  /SDQ_Score CDQ_Score Tobin_Q_raw Firm_Size Leverage_raw ROA_raw Firm_Age (SCALE).

FORMATS SDQ_Score CDQ_Score (F8.2) Tobin_Q_raw Firm_Size Leverage_raw ROA_raw (F8.4).

* --- 1.3 Completeness screen --------------------------------------------------.
* Confirm the panel is balanced on the two disclosure indices and the
* Tobin's Q components before proceeding (per Chapter 3, s.3.5-3.6: purposive
* census of firms with complete data for the 2021-2025 window).

FREQUENCIES VARIABLES=SDQ_Score CDQ_Score Tobin_Q_raw Firm_Size Leverage_raw
  Firm_Age
  /FORMAT=NOTABLE
  /STATISTICS=NONE
  /MISSING.

* Expect 0 missing on SDQ_Score/CDQ_Score/Tobin_Q_raw across all 611 rows.
* If any case shows missing here, exclude and document under 3.6 (Sampling
* Technique) rather than silently imputing.

* --- 1.4 Data-quality flag: provisional (not-yet-verified) disclosure scores -.
* 8 of 611 firm-years (1.3%) carry a provisional SDQ/CDQ score of 0, pending
* access to the underlying Annual Report/Sustainability Report (see the
* 'Notes / Data Quality Flags' column in the source workbook; rows marked
* 'NOT YET CODED' / 'NOT YET DONE' / 'genuine access gap' for the SDQ/CDQ
* items specifically). These are retained in the main analysis - each
* score reflects the best available evidence at time of coding - but
* flagged here so a sensitivity check can exclude them.
*
* This is the single source of truth for provisional-row status: it is
* saved into NGX_Panel_Analysis.sav, and 05_Robustness_Tests.sps reads
* Coding_Status_Flag from that file directly rather than keeping its own
* copy of the list. If a future coding pass resolves any of the 8 rows
* below (or flags new ones), update the IF statements here only.

STRING Coding_Status_Flag (A20).
COMPUTE Coding_Status_Flag = 'Fully verified'.
IF (Firm_ID = 1 AND Year = 2022) Coding_Status_Flag = 'Provisional (0)'.
IF (Firm_ID = 1 AND Year = 2023) Coding_Status_Flag = 'Provisional (0)'.
IF (Firm_ID = 1 AND Year = 2025) Coding_Status_Flag = 'Provisional (0)'.
IF (Firm_ID = 2 AND Year = 2021) Coding_Status_Flag = 'Provisional (0)'.
IF (Firm_ID = 2 AND Year = 2023) Coding_Status_Flag = 'Provisional (0)'.
IF (Firm_ID = 3 AND Year = 2021) Coding_Status_Flag = 'Provisional (0)'.
IF (Firm_ID = 3 AND Year = 2022) Coding_Status_Flag = 'Provisional (0)'.
IF (Firm_ID = 3 AND Year = 2023) Coding_Status_Flag = 'Provisional (0)'.
EXECUTE.
* Tickers, for cross-reference against the workbook: ABBEYBANK (id 1),
* ABCTRANS (id 2), ACADEMY (id 3).
VARIABLE LABELS Coding_Status_Flag 'SDQ/CDQ coding verification status'.
VALUE LABELS Coding_Status_Flag 'Fully verified' 'Fully verified'
                                'Provisional (0)' 'Provisional (0) - pending Annual Report access'.

* --- 1.5 Winsorize the control/valuation variables at the 0.5th/99.5th pct ---.
* Matches the workbook's live PERCENTILE.INC treatment (Table 5 note):
* caps extreme leverage/Tobin's Q outliers while preserving genuine
* high-growth values.

* SPSS has no single worksheet-style PERCENTILE.INC equivalent usable
* inline, so winsorizing is a two-step process:
*   Step 1 - obtain the 0.5th/99.5th percentile cut points.

EXAMINE VARIABLES=Tobin_Q_raw Leverage_raw ROA_raw
  /PERCENTILES(0.5,99.5) HAVERAGE
  /PLOT=NONE
  /STATISTICS=NONE.

*   Step 2 - read the two cut points per variable from the pivot table
*   output above and hard-code them into the RECODE statements below.
*   (Values shown are those actually used for this thesis, taken from the
*   workbook's live PERCENTILE.INC formulas - Table 5, '5. Controls &
*   Correlation' tab - and reproduced here for an exact match.)

RECODE Tobin_Q_raw (LOWEST THRU 0.43 = 0.43) (11.33 THRU HIGHEST = 11.33)
  (ELSE = COPY) INTO Tobin_Q_Wins.
RECODE Leverage_raw (LOWEST THRU 0.04 = 0.04) (3.35 THRU HIGHEST = 3.35)
  (ELSE = COPY) INTO Leverage_Wins.
RECODE ROA_raw (LOWEST THRU -0.70 = -0.70) (0.52 THRU HIGHEST = 0.52)
  (ELSE = COPY) INTO ROA_Wins.
EXECUTE.

VARIABLE LABELS
  Tobin_Q_Wins   'Tobin''s Q, winsorized at 0.5/99.5 pct'
  Leverage_Wins  'Leverage, winsorized at 0.5/99.5 pct'
  ROA_Wins       'ROA, winsorized at 0.5/99.5 pct'.

* --- 1.6 Save analysis file --------------------------------------------------.

DATASET ACTIVATE RawPanel.
SAVE OUTFILE='NGX_Panel_Analysis.sav'
  /COMPRESSED.

DISPLAY DICTIONARY.

*=============================================================================.
* End of 01_Data_Preparation.sps
*=============================================================================.
