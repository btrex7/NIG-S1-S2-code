* Encoding: UTF-8.
*=============================================================================.
* 03_CORRELATION.SPS
* Objective 1 (supporting analysis): examine the association between SDQ
* and CDQ themselves, and between each index and the control variables,
* ahead of the Objective 2/3 regressions. Also used here to justify the
* choice of Spearman over Pearson as the lead coefficient (Table 2 shows
* both indices are non-normal).
* Input:  NGX_Panel_Analysis.sav
* Workbook cross-reference: reproduces Table 5, Parts B and C
* (Pearson/Spearman correlation matrices, '5. Controls & Correlation' tab,
* NGX_Stage1_Objective1_Descriptive_Statistics.xlsx), cited there by name.
*=============================================================================.

GET FILE='NGX_Panel_Analysis.sav'.
DATASET NAME Analysis.

* --- Pearson (raw values) -----------------------------------------------------.

CORRELATIONS
  /VARIABLES=SDQ_Score CDQ_Score Tobin_Q_Wins Firm_Size Leverage_Wins Firm_Age
  /PRINT=TWOTAIL NOSIG
  /MISSING=PAIRWISE.

* --- Spearman (rank-based; preferred given the non-normality documented in
* 02_Descriptive_Statistics.sps - Shapiro-Wilk p < .001 for both indices) ---.

NONPAR CORR
  /VARIABLES=SDQ_Score CDQ_Score Tobin_Q_Wins Firm_Size Leverage_Wins Firm_Age
  /PRINT=SPEARMAN TWOTAIL NOSIG
  /MISSING=PAIRWISE.

* --- Interpretation note for Chapter Four -------------------------------------.
* SDQ and CDQ correlate strongly (Pearson r = .828, Spearman rho = .678,
* both p < .001): expected, since every IFRS S2 climate item is also an
* IFRS S1-aligned sustainability item by construction (S2 is the climate
* subset, not an independent domain), but the gap between the Pearson and
* Spearman coefficients is itself informative - it says the linear
* (Pearson) relationship is partly driven by the shared mass of zero
* scores rather than a uniformly tight rank relationship across
* disclosing firms. Report both, flag the construct overlap explicitly
* when discussing Objective 1 alongside Objectives 2 and 3, and note that
* Objectives 2 and 3 model FV~SDQ and FV~CDQ in SEPARATE regressions
* (Chapter Three, s.3.9) specifically to avoid the multicollinearity this
* correlation would otherwise cause if both indices entered one model.
*
* Both indices also correlate moderately with Firm_Size (Pearson r approx.
* .51-.54, Spearman rho approx. .41-.51): larger, more closely monitored
* firms disclose more. This is the empirical justification for carrying
* SIZE as a control variable into the Objective 2/3 regression models
* (04_Regression_Base_Model.sps in the Objective 2/3 workflow), not
* dropping it as redundant with disclosure quality.

*=============================================================================.
* End of 03_Correlation.sps
*=============================================================================.
