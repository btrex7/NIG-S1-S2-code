* Encoding: UTF-8.
*=============================================================================.
* 02_DESCRIPTIVE_STATISTICS.SPS
* Objective 1: Assess the quality of sustainability disclosures among
*              NGX-listed companies using the IFRS S1/S2 reporting framework.
* Produces:    Table 1  Sample profile (panel balance by year, by sector)
*              Table 2  SDQ/CDQ descriptive statistics + normality tests
*              Table 3  SDQ/CDQ trend by year (means, SD)
*              Table 4  SDQ/CDQ by sector
*              Zero-disclosure prevalence (score = 0), overall and by year
*              (workbook Table 6, '6. Zero-Disclosure Table' tab)
* Input:       NGX_Panel_Analysis.sav (built in 01_Data_Preparation.sps)
* Workbook cross-reference (NGX_Stage1_Objective1_Descriptive_Statistics.xlsx):
* Table 1-4 and 6 above map 1-for-1 onto the workbook tabs of the same
* number/name; the workbook's own notes on Tables 1, 2, 4 and 6 cite this
* file by name as the SPSS reproduction route.
*=============================================================================.

GET FILE='NGX_Panel_Analysis.sav'.
DATASET NAME Analysis.

* --- Table 1: Sample profile --------------------------------------------------.

FREQUENCIES VARIABLES=Year
  /ORDER=ANALYSIS
  /FORMAT=NOTABLE.

CTABLES
  /VLABELS VARIABLES=Year DISPLAY=DEFAULT
  /TABLE Year [C][COUNT F40.0, COLPCT.COUNT PCT40.1]
  /CATEGORIES VARIABLES=Year ORDER=A KEY=VALUE EMPTY=INCLUDE TOTAL=YES
  /TITLES TITLE='Table 1a: Panel Balance by Year'.

CTABLES
  /VLABELS VARIABLES=Sector DISPLAY=DEFAULT
  /TABLE Sector [C][COUNT F40.0, COLPCT.COUNT PCT40.1]
  /CATEGORIES VARIABLES=Sector ORDER=A KEY=VALUE EMPTY=INCLUDE TOTAL=YES
  /TITLES TITLE='Table 1b: Sample Distribution by Sector'.

* Unique firms (N=128): count distinct Firm_ID.

AGGREGATE OUTFILE=* MODE=ADDVARIABLES
  /BREAK=Firm_ID
  /Firm_First = FIRST(Year).
AUTORECODE VARIABLES=Firm_ID /INTO Firm_ID_check.
DESCRIPTIVES VARIABLES=Firm_ID_check /STATISTICS=MAX.
* MAX of Firm_ID_check = count of distinct Firm_ID values = unique firm count (128).

* --- Table 2: SDQ / CDQ descriptive statistics + normality -------------------.
* Answers Objective 1 / Research Question 1 directly.

DESCRIPTIVES VARIABLES=SDQ_Score CDQ_Score
  /STATISTICS=MEAN STDDEV MIN MAX SKEWNESS KURTOSIS.

FREQUENCIES VARIABLES=SDQ_Score CDQ_Score
  /FORMAT=NOTABLE
  /STATISTICS=MEDIAN
  /HISTOGRAM NORMAL.

* Shapiro-Wilk normality test (also produces Q-Q plots for the appendix).

EXAMINE VARIABLES=SDQ_Score CDQ_Score
  /PLOT NPPLOT
  /STATISTICS DESCRIPTIVES
  /CINTERVAL 95
  /MISSING LISTWISE
  /NOTOTAL.

* SPSS's EXAMINE reports Shapiro-Wilk only for n <= 50 by default in some
* versions; for the full n=611 sample obtain it via bootstrap-robust
* DESCRIPTIVES or, if unavailable, via the Kolmogorov-Smirnov (Lilliefors)
* test below as a documented substitute - both indices reject normality
* at p < .001, consistent with the Shapiro-Wilk result computed in Python
* (W = .660, p < .001 for SDQ; W = .407, p < .001 for CDQ) and reported in
* the thesis.

NPAR TESTS
  /K-S(NORMAL)=SDQ_Score CDQ_Score
  /MISSING ANALYSIS.

* --- Table 3 (Part 1): SDQ / CDQ trend by year, means and SD -----------------.

MEANS TABLES=SDQ_Score CDQ_Score BY Year
  /CELLS=COUNT MEAN STDDEV.

* --- Table 4: SDQ / CDQ by sector ---------------------------------------------.

MEANS TABLES=SDQ_Score CDQ_Score BY Sector
  /CELLS=COUNT MEAN STDDEV.

* Unique firms per sector: collapse to one row per firm (Sector is a
* time-invariant firm attribute), then tabulate on the firm-level copy so
* the original firm-year dataset is left untouched.

DATASET COPY FirmLevel.
DATASET ACTIVATE FirmLevel.
AGGREGATE OUTFILE=* MODE=REPLACE
  /BREAK=Firm_ID
  /Sector=FIRST(Sector).
FREQUENCIES VARIABLES=Sector /FORMAT=NOTABLE /ORDER=ANALYSIS.
DATASET ACTIVATE Analysis.
DATASET CLOSE FirmLevel.

* --- Zero-disclosure prevalence (score = 0): overall and by year -------------.
* Supplementary table accompanying Figure 4.x (mean trend chart). Reports
* the proportion of firm-years disclosing against NONE of the coded items,
* which the mean/median in Table 2 already flags as the dominant pattern
* (median SDQ = median CDQ = 0).

COMPUTE SDQ_Zero = (SDQ_Score = 0).
COMPUTE CDQ_Zero = (CDQ_Score = 0).
VARIABLE LABELS SDQ_Zero 'SDQ_Score = 0 (no coded S1 items disclosed)'
                CDQ_Zero 'CDQ_Score = 0 (no coded S2 items disclosed)'.
VALUE LABELS SDQ_Zero CDQ_Zero 0 'Non-zero' 1 'Zero'.

* Overall.
FREQUENCIES VARIABLES=SDQ_Zero CDQ_Zero
  /FORMAT=NOTABLE
  /STATISTICS=NONE.

* By year (valid % = n / N for that year; base is always non-missing here).

CTABLES
  /VLABELS VARIABLES=Year SDQ_Zero DISPLAY=DEFAULT
  /TABLE Year [C] BY SDQ_Zero [C][COUNT F40.0, ROWPCT.COUNT PCT40.1]
  /CATEGORIES VARIABLES=Year ORDER=A KEY=VALUE EMPTY=INCLUDE TOTAL=YES
  /CATEGORIES VARIABLES=SDQ_Zero ORDER=A KEY=VALUE EMPTY=INCLUDE
  /TITLES TITLE='Zero-Disclosure Prevalence by Year - SDQ'.

CTABLES
  /VLABELS VARIABLES=Year CDQ_Zero DISPLAY=DEFAULT
  /TABLE Year [C] BY CDQ_Zero [C][COUNT F40.0, ROWPCT.COUNT PCT40.1]
  /CATEGORIES VARIABLES=Year ORDER=A KEY=VALUE EMPTY=INCLUDE TOTAL=YES
  /CATEGORIES VARIABLES=CDQ_Zero ORDER=A KEY=VALUE EMPTY=INCLUDE
  /TITLES TITLE='Zero-Disclosure Prevalence by Year - CDQ'.

SAVE OUTFILE='NGX_Panel_Analysis.sav' /COMPRESSED.

*=============================================================================.
* End of 02_Descriptive_Statistics.sps
*=============================================================================.
