* Encoding: UTF-8.
*=============================================================================.
* 04_REGRESSION_BASE_MODEL.SPS
* Objective 1 (trend component): is disclosure quality improving over the
* 2021-2025 study window? Tested with a firm fixed-effects regression of
* each index on (centred) year, NOT a between-year comparison - see the
* rationale in the comment block below.
*
* NOTE ON TOOLING: the point estimates and clustered standard errors
* actually reported in Chapter Four (Table 3, Part 2) were produced in
* Python (statsmodels: entity-demeaned OLS for the coefficient/within R-sq,
* least-squares dummy-variable regression with firm-clustered
* cluster-robust covariance for the SE/t/p) and are numerically identical
* to what R's plm(model='within') with vcovHC(cluster='group') returns.
* Plain SPSS syntax cannot reproduce firm-clustered standard errors inside
* an ordinary REGRESSION call; the workflow below reproduces the point
* estimate exactly (entity-demeaning) and approximates the clustered SE
* using GENLIN's repeated-measures robust ("sandwich") estimator, which is
* the closest native SPSS equivalent. Treat the GENLIN SE/p-values as an
* approximation for cross-checking, not as the number to cite - cite the
* Python/R figures reported in Table 3.
*
* Input:  NGX_Panel_Analysis.sav
* Workbook cross-reference: reproduces Table 3, Part 2 (Firm Fixed-Effects
* Trend Regression, rows 11-20 of the '3. Trend by Year' tab,
* NGX_Stage1_Objective1_Descriptive_Statistics.xlsx), cited there by name.
*=============================================================================.

GET FILE='NGX_Panel_Analysis.sav'.
DATASET NAME Analysis.

* --- Why firm fixed effects, not a between-year test --------------------------.
* SDQ_Score and CDQ_Score are repeated observations on the same 128 firms
* across 5 years, not independent cross-sections. A between-year comparison
* (Kruskal-Wallis/ANOVA on Year) would mix genuine within-firm improvement
* with persistent between-firm differences: a consistently high-disclosing
* bank sitting next to a consistently zero-disclosing firm every year looks
* like "no trend" to a between-group test even when every firm individually
* improves. Firm fixed effects (entity-demeaning) removes that confound by
* asking only whether each firm's OWN score moved over time.

COMPUTE Year_c = Year - 2021.
VARIABLE LABELS Year_c 'Year, centred on 2021 (0-4)'.

* --- Entity-demean SDQ_Score, CDQ_Score and Year_c by firm --------------------.

AGGREGATE OUTFILE=* MODE=ADDVARIABLES
  /BREAK=Firm_ID
  /SDQ_FirmMean=MEAN(SDQ_Score)
  /CDQ_FirmMean=MEAN(CDQ_Score)
  /Yearc_FirmMean=MEAN(Year_c).

COMPUTE SDQ_Score_dm = SDQ_Score - SDQ_FirmMean.
COMPUTE CDQ_Score_dm = CDQ_Score - CDQ_FirmMean.
COMPUTE Year_c_dm = Year_c - Yearc_FirmMean.
EXECUTE.

* --- Point estimate: OLS on entity-demeaned data (= within estimator) --------.
* Matches the coefficient reported in Table 3, Part 2 exactly
* (SDQ: b = 1.479; CDQ: b = 1.2863).

REGRESSION
  /DEPENDENT SDQ_Score_dm
  /METHOD=ENTER Year_c_dm
  /STATISTICS COEFF R ANOVA.

REGRESSION
  /DEPENDENT CDQ_Score_dm
  /METHOD=ENTER Year_c_dm
  /STATISTICS COEFF R ANOVA.

* NOTE: the R-squared from these two REGRESSION calls IS the correct
* within R-squared reported in Table 3 (3.8% for SDQ, 4.6% for CDQ) because
* it is computed on entity-demeaned data. The default standard errors,
* t-statistics and p-values from REGRESSION above are NOT firm-clustered
* and will differ from Table 3 - use the GENLIN block below for a
* clustered-SE approximation, or cite the Python/R result directly.

* --- Clustered-SE approximation via GENLIN repeated-measures robust SE -------.

GENLIN SDQ_Score_dm WITH Year_c_dm
  /MODEL Year_c_dm INTERCEPT=YES
  /REPEATED SUBJECT=Firm_ID CORRTYPE=INDEPENDENT ADJUSTCORR=YES
    COVB=ROBUST
  /MISSING CLASSMISSING=EXCLUDE
  /PRINT SOLUTION.

GENLIN CDQ_Score_dm WITH Year_c_dm
  /MODEL Year_c_dm INTERCEPT=YES
  /REPEATED SUBJECT=Firm_ID CORRTYPE=INDEPENDENT ADJUSTCORR=YES
    COVB=ROBUST
  /MISSING CLASSMISSING=EXCLUDE
  /PRINT SOLUTION.

* Expected result to report in Chapter Four (from the Python/R analysis):
*   SDQ_Score: b = 1.479 per year, clustered SE = 0.5343, t = 2.768, p = .0056
*   CDQ_Score: b = 1.2863 per year, clustered SE = 0.3868, t = 3.325, p = .0009
*   N = 611 firm-years, 128 firms. Within R-sq: SDQ = .038, CDQ = .046.
* Both indices show a statistically significant, but modest, within-firm
* upward trend once firm fixed effects isolate genuine change over time
* from between-firm heterogeneity.

*=============================================================================.
* End of 04_Regression_Base_Model.sps
*=============================================================================.
