* Encoding: UTF-8.
*=============================================================================.
* 05_ROBUSTNESS_TESTS.SPS
* Objective 1: two robustness/sensitivity checks on the descriptive and
* trend findings reported in 02_Descriptive_Statistics.sps and
* 04_Regression_Base_Model.sps.
*   (a) Sector comparison at the correct unit of analysis (firm level).
*   (b) Sensitivity of headline figures to the firm-years still carrying a
*       provisional ("not yet verified") zero score (8 of 611 as of the
*       current source workbook - see s.1.4 of 01_Data_Preparation.sps).
* Input:  NGX_Panel_Analysis.sav
* Workbook cross-reference (NGX_Stage1_Objective1_Descriptive_Statistics.xlsx):
*   (a) reproduces the firm-level Kruskal-Wallis reported in Table 4, rows
*       35-44 ('4. Sector Breakdown' tab).
*   (b) reproduces the sensitivity note under Table 6, cell A13-A15
*       ('6. Zero-Disclosure Table' tab) - both cite this file by name.
*=============================================================================.

GET FILE='NGX_Panel_Analysis.sav'.
DATASET NAME Analysis.

*-----------------------------------------------------------------------------.
* (a) SECTOR COMPARISON: KRUSKAL-WALLIS AT FIRM LEVEL, NOT FIRM-YEAR LEVEL.
*-----------------------------------------------------------------------------.
* Sector is a fixed, time-invariant firm attribute. Testing it against
* repeated firm-year observations (n=611) would count each firm's
* disclosure level up to five times as if it were five independent pieces
* of evidence, overstating significance - the Moulton (1990) problem for
* grouped/clustered micro data. Collapsing to one row per firm (n=128)
* before testing avoids this.

DATASET COPY FirmLevel.
DATASET ACTIVATE FirmLevel.
AGGREGATE OUTFILE=* MODE=REPLACE
  /BREAK=Firm_ID
  /Sector=FIRST(Sector)
  /SDQ_FirmMean=MEAN(SDQ_Score)
  /CDQ_FirmMean=MEAN(CDQ_Score).

* Sector is imported as TEXT (13 sector-name strings, e.g. 'FINANCIAL
* SERVICES', 'OIL AND GAS'), not a numeric 1-13 code, and NPAR TESTS K-W's
* "BY groupvar(low,high)" range syntax requires a NUMERIC grouping
* variable. AUTORECODE gives a numeric 1-13 version first, in the same
* alphabetical order CTABLES uses elsewhere in 02_Descriptive_Statistics.sps
* for consistency.

AUTORECODE VARIABLES=Sector /INTO Sector_Num /PRINT.

NPAR TESTS
  /K-W=SDQ_FirmMean CDQ_FirmMean BY Sector_Num(1 13)
  /MISSING ANALYSIS.

* Expected result (from the Python/SciPy analysis reported in Table 4):
*   SDQ_FirmMean by Sector: H = 23.84, df = 12, p = .021 -> significant.
*   CDQ_FirmMean by Sector: H = 17.87, df = 12, p = .120 -> not significant.
* Interpretation: a modest but genuine sector effect for general
* sustainability disclosure quality (Oil & Gas, Financial Services and
* Healthcare disclose the most); no significant sector effect for
* climate-related disclosure quality once tested at the correct level.
* Caution: Investment (N=1 firm), Utilities (N=2) and Natural Resources
* (N=2) rest on very few firms - interpret their individual ranking
* position with that in mind, independent of the omnibus test result.

DATASET ACTIVATE Analysis.
DATASET CLOSE FirmLevel.

*-----------------------------------------------------------------------------.
* (b) SENSITIVITY CHECK: EXCLUDING PROVISIONAL (NOT-YET-VERIFIED) ZERO SCORES.
*-----------------------------------------------------------------------------.
* This check reads Coding_Status_Flag directly from the .sav file built in
* 01_Data_Preparation.sps s.1.4, rather than keeping a separate list here -
* if a future coding pass changes which rows are provisional, update the
* IF statements in 01 s.1.4 only and this check picks it up automatically
* on the next run of the whole 01-06 pipeline.

DATASET COPY Sensitivity.
DATASET ACTIVATE Sensitivity.
SELECT IF (Coding_Status_Flag <> 'Provisional (0)').
EXECUTE.

DESCRIPTIVES VARIABLES=SDQ_Score CDQ_Score
  /STATISTICS=MEAN STDDEV MIN MAX SKEWNESS KURTOSIS.

COMPUTE SDQ_Zero = (SDQ_Score = 0).
COMPUTE CDQ_Zero = (CDQ_Score = 0).
FREQUENCIES VARIABLES=SDQ_Zero CDQ_Zero
  /FORMAT=NOTABLE.

* Expected result (n=603 after excluding the 8 provisional rows, vs. n=611
* full sample):
*   SDQ: mean 13.151 -> 13.284, zero-prevalence 55.65% -> 55.72%
*   CDQ: mean 6.370  -> 6.455,  zero-prevalence 82.65% -> 82.42%
* Every figure moves by well under one percentage point. The headline
* Objective 1 findings are not sensitive to how these 8 provisional rows
* (1.3% of the panel) are treated. Report this as a one-sentence
* robustness note in Chapter Four rather than a full sub-section.

DATASET ACTIVATE Analysis.
DATASET CLOSE Sensitivity.

*=============================================================================.
* End of 05_Robustness_Tests.sps
*=============================================================================.
